<?php


session_start();




require("../confige/ana_soc_data.php");

require("../confige/social_post.php");

$id=$_SESSION['id'];




$tz = 'America/Los_Angeles';
$tz_obj = new DateTimeZone($tz);
$today = new DateTime("now", $tz_obj);
$today_formatted = $today->format('Y-m-d H:i:s');


$late_time=strtotime($today_formatted);













$json_data=$_POST['camp_data'];

$get_name_data=$json_data['post_name'];


$db_name=$id."^".base64_encode($get_name_data);

$get_txt_data=$json_data['txt_data_post'];

$get_img_data=$json_data['img_data_post'];


$get_url_data=$json_data['url'];

if(!empty($get_url_data)){

$get_url_data="https://heptera.me/url/?".uniqid();

}else{

$get_url_data=uniqid();
}



$get_date_data=$json_data['date_lnc'];




$past=strtotime($get_date_data);




if($past<$late_time){



echo 3;

}else{



$insrt_query_data="insert into camp_soc_hy VALUES('$id','$db_name','$get_img_data','$get_txt_data','$get_date_data','1','$get_url_data')";

if ($social_post_conn->query($insrt_query_data) === TRUE){


	if(!empty($json_data['url'])){

$tblsql = "CREATE TABLE `".$db_name."`(
     tp_acc varchar(3) NOT NULL,
     ip_dt varchar(3),
lat varchar(4),lag varchar(5),
     acc_date datetime
        
        )";




if ($ana_soc_conn->query($tblsql) === TRUE) {



	echo $db_name.",".$get_url_data;



}else{
	echo 2;
}



	}else{


 echo $db_name.",".$get_url_data;

	}




}else{

	
	
	echo 2;
}

}




?>
