<?php






function httpGet($url)
{
    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false); 

    $output=curl_exec($ch);

    curl_close($ch);
    return $output;
}






function httpPost($url,$params)
{
	$p=0;

  $postData = '';
   //create name value pairs seperated by &
   foreach($params as $k => $v)
   {
      $postData .= $k . '='.$v.'&';

$p=$p+1;
   }


   $postData = rtrim($postData, '&');

    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_POST, $k);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

    $output=curl_exec($ch);

    curl_close($ch);
    return $output;
          
}        
   

function convertDateTime($time = '', $fromTimezone = '', $toTimezone = '')
{
    $date = new DateTime($time, new DateTimeZone($fromTimezone));
    $date->setTimezone(new DateTimeZone($toTimezone));
    return $date->format('Y-m-d H:i:s');
}





   function fb_account_sheduled($acc_tok,$acc_det,$post_data){




$post_time=convertDateTime($post_data['date_lnc'],'America/Los_Angeles','UTC');

  

$param_post=array();

$url="https://graph.facebook.com/v7.0/me?fields=accounts{id,access_token}&access_token=".$acc_tok;
    


$get_data=httpGet($url);

$id_arr=json_decode($get_data);

if(strlen($post_data['img_data_post'])>0){

$array_of_img=explode(",", $post_data['img_data_post']);



}

$cnt_img=count($array_of_img);


foreach($id_arr->accounts->data as $value){


        if($value->id==$acc_det){


          if($cnt_img>0){



for($i=0;$i<$cnt_img-1;$i++) {
  





$pub_photo="https://graph.facebook.com/v7.0/".$value->id."/photos";

$img_url='https://heptera.me/dash/main/studio/ajaxfile/images/'.$array_of_img[$i];


$param_photos=array (
      'url' => $img_url,
      'published' => 'false',
      'access_token'=>$value->access_token
    );



$json_dec_photo=json_decode(httpPost($pub_photo,$param_photos));

$photo_id_name="attached_media[".$i."]";

$param_post[$photo_id_name]='{media_fbid:'.$json_dec_photo->id.'}';


}



}

$fb_shed_post_url="https://graph.facebook.com/v7.0/".$value->id."/feed";


$param_post['message']=$post_data['txt_data_post'];
$param_post['link']=$post_data['url'];
$param_post['access_token']=$value->access_token;




$get_data=httpPost($fb_shed_post_url,$param_post);


return $get_data;

break;





        }

}











}










?>
