<?php






function create_db($conn,$db_name){




$sql = "CREATE DATABASE ".$db_name;
if ($conn->query($sql) === TRUE) {

echo "create db ".$db_name;

}




}




function create_tbl_in_db($conn,$sql){



if($conn->query($sql)==TRUE){

echo "create Table ";

}




}






$servername = "database-1.cva6ptwfw7oc.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";



$db_conn = mysqli_connect($servername, $username, $password);



#create all database

create_db($db_conn,"social_post");

create_db($db_conn,"part_multi_soc");

create_db($db_conn,"ana_soc");



#create social_post Table




$tbl_query="CREATE TABLE `camp_soc_hy` (
 `id` varchar(23) DEFAULT NULL,
 `post_name` varchar(255) NOT NULL,
 `img` varchar(255) DEFAULT NULL,
 `text` varchar(255) DEFAULT NULL,
 `date_time` datetime DEFAULT NULL,
 `flg_send` int(2) DEFAULT NULL,
 `url` varchar(50) DEFAULT NULL,
 PRIMARY KEY (`post_name`),
 UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

$db_conn=mysqli_connect($servername, $username, $password,"social_post");


create_tbl_in_db($db_conn,$tbl_query);



$tbl_query="CREATE TABLE `post_data_url` (
 `camp_id` varchar(20) DEFAULT NULL,
 `url` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1";



create_tbl_in_db($db_conn,$tbl_query);

$tbl_query="CREATE TABLE `post_que_data` (
 `id` varchar(255) DEFAULT NULL,
 `token` varchar(255) DEFAULT NULL,
 `camp_name` varchar(255) DEFAULT NULL,
 `flg_send` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1";




create_tbl_in_db($db_conn,$tbl_query);






$db_conn=mysqli_connect($servername, $username, $password,"part_multi_soc");





$tbl_query="CREATE TABLE `multi_soc_acc` (
 `id` int(11) DEFAULT NULL,
 `acc_tok` varchar(255) DEFAULT NULL,
 `add_date` datetime DEFAULT NULL,
 `app_id` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1";






create_tbl_in_db($db_conn,$tbl_query);




?>