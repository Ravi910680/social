<?php
$servername = "database-1.cva6ptwfw7oc.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="ana_soc";

$ana_soc_conn = mysqli_connect($servername, $username, $password,$db);

?>


