<?php


function convertDateTime($time = '', $fromTimezone = '', $toTimezone = '')
{
    $date = new DateTime($time, new DateTimeZone($fromTimezone));
    $date->setTimezone(new DateTimeZone($toTimezone));
    return $date->format('Y-m-d H:i:s');
}



echo convertDateTime("2020-04-12 00:45:00", 'Pacific/Chatham', 'UTC');



?>
