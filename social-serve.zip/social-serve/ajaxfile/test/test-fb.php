<?php






function httpGet($url)
{
    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false); 

    $output=curl_exec($ch);

    curl_close($ch);
    return $output;
}






function httpPost($url,$params)
{
	$p=0;

  $postData = '';
   //create name value pairs seperated by &
   foreach($params as $k => $v)
   {
      $postData .= $k . '='.$v.'&';

$p=$p+1;
   }


   $postData = rtrim($postData, '&');

    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_POST, $k);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

    $output=curl_exec($ch);

    curl_close($ch);
    return $output;
          
}        
   

function convertDateTime($time = '', $fromTimezone = '', $toTimezone = '')
{
    $date = new DateTime($time, new DateTimeZone($fromTimezone));
    $date->setTimezone(new DateTimeZone($toTimezone));
    return $date->format('Y-m-d H:i:s');
}





   function fb_account_sheduled($acc_tok,$acc_det,$post_data){




$post_time=convertDateTime($post_data['date_lnc'],'America/Los_Angeles','UTC');
echo $post_time;
  

$param_post=array();

$url="https://graph.facebook.com/v7.0/me?fields=accounts{id,access_token}&access_token=".$acc_tok;
    


$get_data=httpGet($url);

$id_arr=json_decode($get_data);

if(strlen($post_data['img_data_post'])>0){

$array_of_img=explode(",", $post_data['img_data_post']);



}

$cnt_img=count($array_of_img);


foreach($id_arr->accounts->data as $value){


        if($value->id==$acc_det){


          if($cnt_img>0){



for($i=0;$i<$cnt_img-1;$i++) {
  





$pub_photo="https://graph.facebook.com/v7.0/".$value->id."/photos";


$url_img='https://heptera.me/dash/main/studio/ajaxfile/images/'.$array_of_img[$i];
$param_photos=array (
      'url' => $url_img,
      'published' => 'false',
      'access_token'=>$value->access_token
    );



$json_dec_photo=json_decode(httpPost($pub_photo,$param_photos));

print_r($json_dec_photo);

$photo_id_name="attached_media[".$i."]";

$param_post[$photo_id_name]='{media_fbid:'.$json_dec_photo->id.'}';


}



}

$fb_shed_post_url="https://graph.facebook.com/v7.0/".$value->id."/feed";


$param_post['scheduled_publish_time']=$post_time;
$param_post['message']=$post_data['txt_data_post'];
$param_post['link']=$post_data['url'];
$param_post['published']='false';
$param_post['access_token']=$value->access_token;


print_r($param_post);

$get_data=httpPost($fb_shed_post_url,$param_post);


break;





        }

}











}

$post_data_get=array(
    "url"=> "",
    "post_name" => "njdjcdcd",
    "txt_data_post" => "ravi989871",
    "img_data_post" => "16^c29jX2NvZGU=^106.jpeg,",
    "date_lnc" => "2020-07-04T22:42"
);



fb_account_sheduled("EAAHjQOYU9S4BAN0IzQc3jqoXIVuzKJSIJITj4iQtkGOZBg4JqhrwLgXzF1Tu6ZBBXFssrR0Y21LuotIhrzszW4ZBSbbpYY30jIaFMxoqXZBsTL1go0l2L7EIcbdC9BbxQfxPwp4fZAp9MFgyP5metJlTV75IKERhmVRjIDbeeIAZDZD","369744070151457",$post_data_get);









?>
