<?php

$arr={url: "", post_name: "njdjcdcd", txt_data_post: "ravi989871", img_data_post: "16^c29jX2NvZGU=^106.jpeg,", date_lnc: "2020-07-04T12:42"};
echo $arr['post_name'];
?>
