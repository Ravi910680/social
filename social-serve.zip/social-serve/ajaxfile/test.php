<?php

print_r(explode("$","ravi"));



?>
